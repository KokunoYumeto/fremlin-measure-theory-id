# Fondasi Teori Ukuran — Jilid 1

Adaptasi Bahasa Indonesia dari *Measure Theory*, Volume 1: *The Irreducible Minimum*, karya D. H. Fremlin.

## Status

Jilid 1 lengkap: 102 halaman resmi sumber, 110 halaman A4 hasil reflow, 198 latihan, dan 55 petunjuk sumber. Sasaran korpus tetap Jilid 1–2 lengkap (672 halaman resmi); Jilid 2 belum lengkap pada rilis `0.12.0-v1` ini.

## Mulai membaca

- PDF: `00_READ_FIRST_FONDASI_TEORI_UKURAN_JILID_1.pdf`
- Pembaca HTML luring: `output/fondasi-teori-ukuran-v1-id/html/index.html`
- Sumber editabel Bahasa Indonesia: `source/id-ID/`
- Backend semantik: `backend/volume1-closure/` dan `backend/index/`
- Identitas setiap berkas: `PACKAGE_MANIFEST.tsv`

## Reproduksi

Jalankan dari akar paket dengan Python 3, TeX/AMS-TeX, `dvipdfmx`, Ghostscript, Poppler, dan dependensi terbuka yang setara:

```text
python scripts/build_volume1.py
python backend/validate_volume1_closure.py
python scripts/render_volume1_html.py
python scripts/qa_volume1_pdf.py
```

`output/fondasi-teori-ukur-v1-chapter13-id/html/` dipertahankan sebagai basis byte-frozen yang digunakan pembangun HTML kumulatif. Arsip sumber resmi Jilid 2 turut dipertahankan agar pekerjaan dapat dilanjutkan, tetapi paket ini tidak mengklaim bahwa Jilid 2 sudah diterjemahkan.

## Hak dan atribusi

Materi turunan Fremlin didistribusikan menurut Design Science License dalam `LICENSE`. D. H. Fremlin tetap dikreditkan sebagai penulis karya sumber. MathJax 3.2.2 adalah komponen terpisah berlisensi Apache-2.0; teks lisensinya ada di `THIRD_PARTY_LICENSES/MathJax-3.2.2-Apache-2.0.txt`. Rincian perubahan dan atribusi ada di `ATTRIBUTION.md` dan `00_control/RIGHTS_AND_ATTRIBUTION.md`.

Provenans produksi: OpenAI Codex gpt-5.6-sol, Ultra.
