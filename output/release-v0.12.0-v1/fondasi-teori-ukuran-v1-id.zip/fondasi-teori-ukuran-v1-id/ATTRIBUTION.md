# Attribution and modification notice

- Source work: D. H. Fremlin, *Measure Theory*, Volume 1, *The Irreducible Minimum* (official 2011 source archive).
- Indonesian derivative working title: *Fondasi Teori Ukuran — Adaptasi Bahasa Indonesia dari Measure Theory karya D. H. Fremlin, Jilid 1*.
- Modification: complete Bahasa Indonesia translation of Volume 1; reflowable PDF and offline HTML presentation; stable semantic IDs, indexes, provenance, correction ledger, and deterministic backend exports.
- Modification date: 24 August 2026.
- Production provenance: OpenAI Codex gpt-5.6-sol, Ultra.
- The Fremlin-derived work remains under the Design Science License. MathJax 3.2.2 is separately licensed under Apache-2.0.

No part of this package claims authorship of Fremlin's original mathematics. Detailed source identities, component boundaries, and correction records are preserved under `00_control/` and `authority/fremlin/`.
